<template>
  <v-content>
    <router-view/>
  </v-content>
</template>

<script>
export default {
  name: 'Body'
}
</script>

<style scoped>

</style>